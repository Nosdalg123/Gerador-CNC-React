# Trilha de código — React 3.1.4

Leia `MAPA-CODIGO.md` e este arquivo antes de editar. `PROJECT_INDEX.json` contém caminhos, tamanhos, hashes SHA-256, imports e símbolos com faixas de linhas. `GRAFO-CODIGO.json` acrescenta chamadas, relações JSX, dependências e conceitos locais. Use as consultas de `pnpm mapa:query`; confirme os trechos encontrados no fonte. Implementação local inspirada no Graphify, sem executar o produto Graphify.

**Padrão vigente desde 11/10/2026:** usar somente a versão leve nas próximas modificações, testes e entregas. Instruções persistentes em `AGENTS.md`. `pnpm start` e `pnpm desktop` abrem o lançador leve; `pnpm package` empacota a versão leve após `pnpm build`; `pnpm test:ui` testa essa distribuição. As referências a Electron abaixo documentam a implementação anterior.

## Fluxos e pontos de entrada

| Objetivo | Entrada | Dependências e dados |
|---|---|---|
| Inicialização e sessão | `src/main.jsx`, `src/App.jsx` | Motores globais carregados por `index.html`; workspace carregado antes de salvar |
| Gerar programa | `src/components/Generator.jsx` → `src/domain.mjs:generate` | `CNC.GERADORES`, ferramentas, desenho selecionado, configurações |
| Desenho manual por elementos | `src/components/Drawing.jsx` → `PieceBuilder.jsx`, `src/piece-elements.mjs` | Paleta/croquis em `src/assets/element-drawings.mjs`; arrays `trechos1/2`, `internos1/2`; IDs e campos extras preservados |
| Raios e chanfros de cones | `core.js:psCantosPerfil`, `psCurvaCanto`, `psContornoComCones` | Tangência em Z/raio; macros 600+ externas e 800+ internas; validadores de arestas, sobreposição e canais |
| Ferramentas | `src/components/Tools.jsx` | T, tipo, parâmetros de corte e geometria; campos adicionais preservados |
| Interpretar TXT | `src/components/Program.jsx` | `CNCProg.interpretar`, `montarCena`, `CNCDiag.diagnosticar` |
| Remover material | `src/components/Simulation.jsx` | `CNCSim.Sim`, seek, grades de material e placa, alertas |
| PDF local | `src/components/PdfImport.jsx` | pdf.js local → cotas → reconhecimento → linhas vetoriais → orientação → perfil |
| Evitar resultado PDF atrasado | `src/pdf-state.mjs` | revision/completedRevision; invalidar confirmação antes de nova leitura |
| Importar e preservar | `src/data.mjs` → `Backup.jsx` | parseTransfer, mergeWorkspace, remapeamento de IDs em seleções |
| Persistir no Windows · versão leve | `lightweight/Servidor-CNC.ps1` → ponte `desktop` → `src/App.jsx` | API local com token/origem, escrita temporária e substituição, backup anterior, proteção contra alteração externa |
| Persistir no navegador | `src/data.mjs:saveBrowser` | chave `cnc.react.workspace.v3` + cópia anterior |
| Construir / empacotar · versão leve | `vite.config.mjs`, `scripts/package-light.cjs` | `pnpm build` → `dist` → `pnpm package` → `release/CNC-Torno-Leve` |

## Motores reaproveitados

`public/engine/core.js`: validação, geometrias, ciclos e sete geradores públicos. `sim.js`: remoção de material e colisões. `progsim.js`: macros, ciclos Fanuc, movimentos e montagem de cena. `diagnostico.js`: catálogo, diagnóstico e correções. `seed.js`: ferramentas iniciais. `pecaview.js`: projeção SVG. `pdfdimensions.js`, `pdfrecognizer.js`, `pdfvector.js`, `pdforientation.js`, `pdfprofile.js`: extração assistida e projeção de desenho.

## Regras para manutenção

1. Edite somente esta versão nova; preserve o ZIP e a pasta analisada.
2. Mudanças no motor: execute testes existentes e regressões em `tests/regression.test.cjs`.
3. Não substituir variável de sistema desconhecida por zero. Não apresentar uma interpretação truncada como completa.
4. Qualquer alteração de vista PDF deve invalidar a confirmação antes de operações assíncronas. Ignore respostas de revisões anteriores.
5. Preserve campos desconhecidos dos registros importados; não sobrescreva registros diferentes que tenham o mesmo ID.
6. A interface não tem acesso direto a Node; novos acessos ao disco passam pela API local do servidor PowerShell, com validação de token/origem e proteção dos dados existentes.
7. Não gerar G-code com T inválido ou diâmetro usinado não positivo.

## Verificação

`tests/regression.test.cjs`: falhas corrigidas e migração. `scripts/test-legacy.cjs`: suíte original dos motores e PDF. `scripts/test-light.cjs`: interface e persistência da distribuição leve em perfil temporário; chama os testes de cotas, PDF e CAD. `tests/light-result.json`: resultado dessa validação. As validações reais da máquina estão em `VALIDAR-NA-MAQUINA.md`. Resultados de testes Electron são históricos.

## CAD DXF da base 2.15.0

CadImport.jsx monta src/assets/cad-panel.html e carrega public/engine/dxfimport.js após existir o DOM. A interface CAD original permanece isolada; os adaptadores CNCDesenhos e CNCDXFDrafts escrevem no workspace React. O painel fica montado durante a navegação para manter o trabalho em curso. dxfcore → dxfchains → dxfprofile → dxfaudit/dxfedit: parser, topologia, perfil, auditoria e operações de edição.

src/domain.mjs bloqueia cadOrigem.incompleto ou verificado=false. Drawing.jsx registra revisão completa e reabre a pendência em qualquer edição. data.mjs importa cnc_dxf_rascunhos_v1 e mescla rascunhos sem remover os atuais. Testes adicionais: scripts/test-cad.cjs e tests/base-update.test.cjs. Origem exata: BASE-GITHUB.json.

## Restauração 3.1.1 e distribuição leve

- `RELATORIO-PARIDADE-3.1.1.md`: achados, correções e tamanhos medidos.
- `src/components/DimensionedDrawing.jsx` e `src/assets/dimensioned-drawings.json`: croquis originais com cotas controladas pelo React.
- `src/domain.mjs:numericFields`: valores numéricos e vazios; `selectedDrawing`: escolha explícita; `programTool/programOrientation`: correspondência de T e orientação.
- `src/components/ToolDrawing.jsx` e `src/assets/tool-drawing.mjs`: desenho original de inserto e suporte, sem DOM legado.
- `lightweight/Servidor-CNC.ps1`: servidor Windows local, ponte de persistência, sessão reutilizável, validação de origem e proteção de dados.
- `scripts/package-light.cjs`: pacote com todos os recursos de produção, sem incluir Electron.
- `scripts/test-light.cjs`: Edge, hash dos recursos e testes de persistência/reabertura em perfil temporário.
- `tests/parity.test.cjs` e `scripts/test-parity-ui.cjs`: regressões de cotas, valores, escolhas e prévias.

## Alcance verificado do índice

`RELATORIO-MAPA-3.1.2.md` registra a implementação vigente e seus testes. A extração AST resolve escopo, imports/exports, funções, callbacks, JSX e APIs UMD dos motores, com evidências de arquivo/linha. Busca por assunto usa vocabulário CNC revisado. Referências não resolvidas, inferidas e ambíguas continuam explícitas; o código confirma o comportamento. `TESTE-TRILHA-CODIGO.md` documenta o estado anterior a 3.1.2. O grafo `G:/GPT/analise-v2.11.0/GRAFO-CODIGO.json` pertence somente à base antiga 2.11.0.

## Autenticação e permissões

`src/App.jsx:11`: perfis locais. `App:13`: sessão. `can:20`, `navigate:21`, `useDrawing:22`: permissões e navegação. Login: linha 25; menu e saída: 26. `src/main.jsx` importa e renderiza App; `index.html` carrega main. As telas recebem controle/ações da raiz, sem importar um módulo de autenticação separado. Relatório: `ARQUITETURA-AUTENTICACAO.md`.

## Atualização e entregas do mapa

`scripts/code-map-ast.cjs`: análise estática. `scripts/code-map.cjs`: hashes, grafo, integridade, cache e snapshots. `code-map.config.json`: vocabulário/rotas. `scripts/query-map.cjs`: consultas e registro de uso. `scripts/watch-map.cjs` + `vite.config.mjs`: observação e vínculo com o build. `scripts/package-light.cjs`: inclui e confere `mapa/` da mesma revisão. `tests/code-map.test.cjs`: 12 testes, incluindo concorrência, observador, integridade, recuperação e empacotamento.

## Restauração do editor 3.1.3

- `PieceBuilder.jsx`: 13 cartões, croquis com campos de cotas, diálogo de edição, seleção SVG/teclado/radio de quinas, prévia, cancelamento sem alteração e lista montada.
- `piece-elements.mjs`: defaults, posição sequencial, descrição e aplicação imutável; editar/reordenar preserva os IDs usados pelas marcas.
- `domain.mjs:drawingPreview`: prévia apenas do lado ativo, inclusive rascunho CAD bloqueado para CNC; referência automática considera os dois diâmetros dos cones. `Drawing.jsx` identifica explicitamente a última prévia válida quando há erro.
- `Drawing.jsx`: importar desenhos antigos usando `parseTransfer`/`mergeWorkspace`, com backup anterior e preservação dos atuais.
- `core.js:psContornoComCones`: ativo somente quando o perfil possui cone e marca. Usa tangentes às duas arestas e valida seu comprimento livre; as saídas antigas de perfis sem essa combinação permanecem no caminho original. O tamanho C é medido nas duas arestas. A validação de canais internos considera o recuo real da tangência, inclusive nas uniões contínuas.
- `tests/piece-elements.test.cjs`: 11 regressões de geometria, macros, G71/G72/G73, quinas, croquis, edição e preservação.
- `scripts/test-piece-editor.cjs`: interface da versão leve em perfil temporário; chamado por `test-light.cjs`. Resultado em `tests/piece-editor-result.json`; imagens em `tests/editor-elementos.png`, `tests/croqui-cone.png` e `tests/raio-cone.png`.
- `Common.jsx:ElementsEditor` permanece nos campos auxiliares de listas do Gerador, por exemplo os furos já existentes no bruto; o editor manual usa `PieceBuilder`.

Relatório desta revisão: `RELATORIO-ELEMENTOS-3.1.3.md`. Fonte anterior preservada em `G:/GPT/backups/react-3.1.2-antes-editor-elementos`; a base GitHub 2.15.0 e a entrega leve 3.1.2 não foram alteradas.

## Edição DXF 3.1.4

- `src/assets/cad-panel.html`: modos quebrar, estender por mm/até próximo elemento e conectar em dois cliques. Retira a seção de listagem das cotas, mantendo conferência e salvamento.
- `public/engine/dxfgeometry.js`: interseções analíticas LINE/ARC/CIRCLE, `breakSegment`, `extendLine`, `extendToNext`, `connectLines`, `dedupeGeometry`. Eixo Y CAD é uma construção infinita usada nos encontros, inclusive Y=0; não entra em `doc.geometry`. Operações trabalham sobre cópia do CAD original; falhas não alteram a geometria.
- Polilinhas: só o pai afetado vira primitivas LINE/ARC, com raio e sentido preservados. `replaceSegments` remapeia os IDs de cada aresta para preservar seleção e exclusões. `geometryDelta`/`restoreGeometry` guardam/reabrem original mais diferenças, incluindo entidades adicionadas e removidas.
- `public/engine/dxfimport.js`: limpeza na importação após clonar `sourceDoc`; soma operações ao histórico, atualiza contagem e IDs e invalida confirmação CNC. Conexão destaca a primeira linha e solicita a segunda; seleção cancelável. `lineEdits` antigo continua sendo lido. Eixo numérico zero de rascunhos não é descartado. Lista de cadeias só atribui perfis nos modos correspondentes, evitando erro ao usá-la em um modo de edição.
- `public/engine/dxfprofile.js`: destaque de edição roxo; eixo visível como limite de corte/extensão, sem interferir nos cliques de linhas. Cotas nativas permanecem na projeção e na auditoria.
- `public/engine/dxfedit.js`: API antiga de extensão segue disponível e encaminha ao módulo geométrico. `index.html` carrega `dxfgeometry.js` antes do editor; `dxfimport.js` usa essa API diretamente para que o mapa registre os consumidores.
- `tests/dxf-geometry.test.cjs`: 17 testes de interseções, eixo zero, arcos, polilinhas, remapeamento, limites, falhas sem mutação, limpeza e delta.
- `scripts/test-dxf-operations.cjs`: Edge, cliques reais, perfil temporário; verifica limpeza, quebra, extensão, conexão/cancelamento, desfazer, confirmação, reabertura atual/legada e preservação. Chamado por `scripts/test-light.cjs`. Resultado: `tests/dxf-operations-result.json`; imagem: `tests/dxf-operations.png`.

Relatório: `RELATORIO-DXF-3.1.4.md`. Backup do fonte anterior: `G:/GPT/backups/react-3.1.3-antes-edicao-dxf`. Entregas 3.1.3 e base 2.15.0 preservadas. Consultas sugeridas: `pnpm mapa:query --query "quebrar conectar eixo central dxf"` e `pnpm mapa:query --callers breakSegment`.

## Meia seção CAD nativa e navegação · 3.1.5

- `cadprofile.js:validate`, `compile`: perfil ordenado em Z/raio, continuidade de 0,001 mm, extremos analíticos dos arcos, raio não negativo e percurso sem retorno em Z. Mantém G2/G3 circular (subdivide somente arcos acima de 90° em arcos circulares), faces G1 e macros existentes de máquina. Não mistura `cadperfil` com elementos manuais.
- `dxfturn.js:build`: cadeia única de duas pontas, sem bifurcações; ordenação pela face, transformação exata e espelhamento do sentido dos arcos. Busca espacial de nós.
- `dxfprofile.js:analyze`, `svg`: seleciona apenas entidades inteiramente superiores; parte inferior tracejada, cinza e recortada. Projeção de edição sem sobrepor cotas numéricas; fonte/dimensões preservadas. `dxfedit.js:autoSelect` usa o mesmo limite superior estrito.
- `dxfaudit.js:check`: aceita o contorno nativo completo; mede seu comprimento, ignora cotas auxiliares como limitantes quando a geometria é válida e confere a face comum do interno. Perfis internos continuam restritos a cilindros/cones.
- `dxfimport.js`: `zoomCamera`, `fitCamera`, arraste da câmera independente da geometria; `makeDraft` dá ID ao rascunho; salvar preserva original mais delta e relaciona `cadOrigem.draftId`. `openSavedContour` reabre o rascunho exato; backup só de desenhos reconstitui contorno nativo sem inventar referência inferior. Edição não bloqueia por si só, mas invalida a confirmação para revisar a geometria resultante.
- `domain.mjs:drawingPreview`: prévia geométrica nativa independente de fixação; `core.js:psContorno` integra o perfil preservando as verificações de máquina. `Drawing.jsx` oferece Editar contorno no CAD; paleta manual permanece nos desenhos de elementos.
- G71 nativo identifica contorno tipo II; desbaste do simulador permanece aproximado tipo I, explicitamente advertido. Raios/centros do acabamento são interpretados e conferidos; isso não constitui validação em torno real.
- `tests/cad-profile.test.cjs`: seis testes de cadeia, reflexo, arcos, falhas, SVG, prévia, fixação e interpretação dos três ciclos. `scripts/test-cad-half.cjs`: zoom/arraste reais, fonte/cotas/dados, meia seção, lacuna bloqueada, salvamento/reabertura completa e backup sem rascunho. Chamado pelo teste leve; `tests/cad-half-result.json` e `tests/cad-half.png`.

Backup anterior: `G:/GPT/backups/react-3.1.4-antes-meia-secao`. Entrega 3.1.4 e base 2.15.0 preservadas. Consulta sugerida: `pnpm mapa:query --query "meia secao superior zoom arco valido"`. Relatório: `RELATORIO-MEIA-SECAO-3.1.5.md`.
