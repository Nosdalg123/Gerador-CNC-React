# CNC Torno — versão leve como padrão

## Decisão persistente do usuário

Em 11/10/2026, o usuário determinou: “daqui em diante vamos usar apenas a versão leve, mesmo nas próximas modificações”.

- Desenvolva, valide e entregue somente a distribuição leve. Não gere nem execute novos pacotes Electron, salvo se o usuário mudar expressamente essa decisão.
- Preserve fontes, executáveis anteriores, backups, base GitHub e dados existentes. A mudança de padrão não autoriza exclusão de arquivos.
- A interface React e os motores CNC continuam os mesmos. Preserve os recursos offline de PDF/DXF, os croquis cotados, simulação, ferramentas, importação e backups.
- Para abrir, use `Iniciar-CNC-Leve.cmd` ou `pnpm start`. `pnpm desktop` também aponta para o lançador leve.
- Para construir, execute `pnpm build`; para empacotar, `pnpm package` (`scripts/package-light.cjs`). A distribuição fica em `release/CNC-Torno-Leve`.
- Para testes pertinentes de interface/persistência, use `pnpm test:ui` (`scripts/test-light.cjs`), que usa Edge e perfil temporário. Não rode testes contra o banco real. Use `pnpm test` e `pnpm test:legacy` conforme a mudança.
- A versão leve usa `lightweight/Servidor-CNC.ps1` com servidor em loopback e navegador instalado. Preserve o caminho `%APPDATA%\CNC Torno React\workspace.json`, a cópia `.previous` e a proteção contra sobrescrita por outra sessão.
- Atualize a trilha `TRILHA-REACT.md` e regenere `PROJECT_INDEX.json` com `node scripts/index.cjs` quando alterar o projeto.

Os arquivos `electron/` e `scripts/package.cjs` ficam como histórico e referência; não são o caminho padrão de execução ou entrega.
