# Trilha de código — React 3.1.2

Leia `MAPA-CODIGO.md` e este arquivo antes de editar. `PROJECT_INDEX.json` contém caminhos, tamanhos, hashes SHA-256, imports e símbolos com faixas de linhas. `GRAFO-CODIGO.json` acrescenta chamadas, relações JSX, dependências e conceitos locais. Use as consultas de `pnpm mapa:query`; confirme os trechos encontrados no fonte. Implementação local inspirada no Graphify, sem executar o produto Graphify.

**Padrão vigente desde 11/10/2026:** usar somente a versão leve nas próximas modificações, testes e entregas. Instruções persistentes em `AGENTS.md`. `pnpm start` e `pnpm desktop` abrem o lançador leve; `pnpm package` empacota a versão leve após `pnpm build`; `pnpm test:ui` testa essa distribuição. As referências a Electron abaixo documentam a implementação anterior.

## Fluxos e pontos de entrada

| Objetivo | Entrada | Dependências e dados |
|---|---|---|
| Inicialização e sessão | `src/main.jsx`, `src/App.jsx` | Motores globais carregados por `index.html`; workspace carregado antes de salvar |
| Gerar programa | `src/components/Generator.jsx` → `src/domain.mjs:generate` | `CNC.GERADORES`, ferramentas, desenho selecionado, configurações |
| Desenho manual | `src/components/Drawing.jsx`, `Common.jsx:ElementsEditor` | Arrays `trechos1/2`, `internos1/2`; migração por `CNC.psMigra` |
| Ferramentas | `src/components/Tools.jsx` | T, tipo, parâmetros de corte e geometria; campos adicionais preservados |
| Interpretar TXT | `src/components/Program.jsx` | `CNCProg.interpretar`, `montarCena`, `CNCDiag.diagnosticar` |
| Remover material | `src/components/Simulation.jsx` | `CNCSim.Sim`, seek, grades de material e placa, alertas |
| PDF local | `src/components/PdfImport.jsx` | pdf.js local → cotas → reconhecimento → linhas vetoriais → orientação → perfil |
| Evitar resultado PDF atrasado | `src/pdf-state.mjs` | revision/completedRevision; invalidar confirmação antes de nova leitura |
| Importar e preservar | `src/data.mjs` → `Backup.jsx` | parseTransfer, mergeWorkspace, remapeamento de IDs em seleções |
| Persistir no Windows · versão leve | `lightweight/Servidor-CNC.ps1` → ponte `desktop` → `src/App.jsx` | API local com token/origem, escrita temporária e substituição, backup anterior, proteção contra alteração externa |
| Persistir no navegador | `src/data.mjs:saveBrowser` | chave `cnc.react.workspace.v3` + cópia anterior |
| Construir / empacotar · versão leve | `vite.config.mjs`, `scripts/package-light.cjs` | `pnpm build` → `dist` → `pnpm package` → `release/CNC-Torno-Leve` |

## Motores reaproveitados

`public/engine/core.js`: validação, geometrias, ciclos e sete geradores públicos. `sim.js`: remoção de material e colisões. `progsim.js`: macros, ciclos Fanuc, movimentos e montagem de cena. `diagnostico.js`: catálogo, diagnóstico e correções. `seed.js`: ferramentas iniciais. `pecaview.js`: projeção SVG. `pdfdimensions.js`, `pdfrecognizer.js`, `pdfvector.js`, `pdforientation.js`, `pdfprofile.js`: extração assistida e projeção de desenho.

## Regras para manutenção

1. Edite somente esta versão nova; preserve o ZIP e a pasta analisada.
2. Mudanças no motor: execute testes existentes e regressões em `tests/regression.test.cjs`.
3. Não substituir variável de sistema desconhecida por zero. Não apresentar uma interpretação truncada como completa.
4. Qualquer alteração de vista PDF deve invalidar a confirmação antes de operações assíncronas. Ignore respostas de revisões anteriores.
5. Preserve campos desconhecidos dos registros importados; não sobrescreva registros diferentes que tenham o mesmo ID.
6. A interface não tem acesso direto a Node; novos acessos ao disco passam pela API local do servidor PowerShell, com validação de token/origem e proteção dos dados existentes.
7. Não gerar G-code com T inválido ou diâmetro usinado não positivo.

## Verificação

`tests/regression.test.cjs`: falhas corrigidas e migração. `scripts/test-legacy.cjs`: suíte original dos motores e PDF. `scripts/test-light.cjs`: interface e persistência da distribuição leve em perfil temporário; chama os testes de cotas, PDF e CAD. `tests/light-result.json`: resultado dessa validação. As validações reais da máquina estão em `VALIDAR-NA-MAQUINA.md`. Resultados de testes Electron são históricos.

## CAD DXF da base 2.15.0

CadImport.jsx monta src/assets/cad-panel.html e carrega public/engine/dxfimport.js após existir o DOM. A interface CAD original permanece isolada; os adaptadores CNCDesenhos e CNCDXFDrafts escrevem no workspace React. O painel fica montado durante a navegação para manter o trabalho em curso. dxfcore → dxfchains → dxfprofile → dxfaudit/dxfedit: parser, topologia, perfil, auditoria e operações de edição.

src/domain.mjs bloqueia cadOrigem.incompleto ou verificado=false. Drawing.jsx registra revisão completa e reabre a pendência em qualquer edição. data.mjs importa cnc_dxf_rascunhos_v1 e mescla rascunhos sem remover os atuais. Testes adicionais: scripts/test-cad.cjs e tests/base-update.test.cjs. Origem exata: BASE-GITHUB.json.

## Restauração 3.1.1 e distribuição leve

- `RELATORIO-PARIDADE-3.1.1.md`: achados, correções e tamanhos medidos.
- `src/components/DimensionedDrawing.jsx` e `src/assets/dimensioned-drawings.json`: croquis originais com cotas controladas pelo React.
- `src/domain.mjs:numericFields`: valores numéricos e vazios; `selectedDrawing`: escolha explícita; `programTool/programOrientation`: correspondência de T e orientação.
- `src/components/ToolDrawing.jsx` e `src/assets/tool-drawing.mjs`: desenho original de inserto e suporte, sem DOM legado.
- `lightweight/Servidor-CNC.ps1`: servidor Windows local, ponte de persistência, sessão reutilizável, validação de origem e proteção de dados.
- `scripts/package-light.cjs`: pacote com todos os recursos de produção, sem incluir Electron.
- `scripts/test-light.cjs`: Edge, hash dos recursos e testes de persistência/reabertura em perfil temporário.
- `tests/parity.test.cjs` e `scripts/test-parity-ui.cjs`: regressões de cotas, valores, escolhas e prévias.

## Alcance verificado do índice

`RELATORIO-MAPA-3.1.2.md` registra a implementação vigente e seus testes. A extração AST resolve escopo, imports/exports, funções, callbacks, JSX e APIs UMD dos motores, com evidências de arquivo/linha. Busca por assunto usa vocabulário CNC revisado. Referências não resolvidas, inferidas e ambíguas continuam explícitas; o código confirma o comportamento. `TESTE-TRILHA-CODIGO.md` documenta o estado anterior a 3.1.2. O grafo `G:/GPT/analise-v2.11.0/GRAFO-CODIGO.json` pertence somente à base antiga 2.11.0.

## Autenticação e permissões

`src/App.jsx:11`: perfis locais. `App:13`: sessão. `can:20`, `navigate:21`, `useDrawing:22`: permissões e navegação. Login: linha 25; menu e saída: 26. `src/main.jsx` importa e renderiza App; `index.html` carrega main. As telas recebem controle/ações da raiz, sem importar um módulo de autenticação separado. Relatório: `ARQUITETURA-AUTENTICACAO.md`.

## Atualização e entregas do mapa

`scripts/code-map-ast.cjs`: análise estática. `scripts/code-map.cjs`: hashes, grafo, integridade, cache e snapshots. `code-map.config.json`: vocabulário/rotas. `scripts/query-map.cjs`: consultas e registro de uso. `scripts/watch-map.cjs` + `vite.config.mjs`: observação e vínculo com o build. `scripts/package-light.cjs`: inclui e confere `mapa/` da mesma revisão. `tests/code-map.test.cjs`: 12 testes, incluindo concorrência, observador, integridade, recuperação e empacotamento.
